﻿#if RISKOFTHUNDER_R2API_ADDRESSABLES
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MSU.AddressReferencedAssets;
using RoR2.Editor.PropertyDrawers;

namespace MSU.Editor
{
    public class AddressReferencedSkinDefDrawer : AddressReferencedAssetDrawer<AddressReferencedSkinDef>
    {

    }
}
#endif