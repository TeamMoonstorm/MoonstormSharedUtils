using ThunderKit.Core.Config;

[assembly: ImportExtensions]